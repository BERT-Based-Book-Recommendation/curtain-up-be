from __future__ import annotations

from .CrossEncoder import CrossEncoder

__all__ = ["CrossEncoder"]
